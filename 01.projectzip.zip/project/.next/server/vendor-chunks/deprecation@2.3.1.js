"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/deprecation@2.3.1";
exports.ids = ["vendor-chunks/deprecation@2.3.1"];
exports.modules = {

/***/ "(ssr)/./node_modules/.pnpm/deprecation@2.3.1/node_modules/deprecation/dist-node/index.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/deprecation@2.3.1/node_modules/deprecation/dist-node/index.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\n\nclass Deprecation extends Error {\n  constructor(message) {\n    super(message); // Maintains proper stack trace (only available on V8)\n\n    /* istanbul ignore next */\n\n    if (Error.captureStackTrace) {\n      Error.captureStackTrace(this, this.constructor);\n    }\n\n    this.name = 'Deprecation';\n  }\n\n}\n\nexports.Deprecation = Deprecation;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvLnBucG0vZGVwcmVjYXRpb25AMi4zLjEvbm9kZV9tb2R1bGVzL2RlcHJlY2F0aW9uL2Rpc3Qtbm9kZS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiQUFBYTs7QUFFYiw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7O0FBRTdEO0FBQ0E7QUFDQSxvQkFBb0I7O0FBRXBCOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBLG1CQUFtQiIsInNvdXJjZXMiOlsid2VicGFjazovL3BlcnNvbmFsLXBvcnRmb2xpby8uL25vZGVfbW9kdWxlcy8ucG5wbS9kZXByZWNhdGlvbkAyLjMuMS9ub2RlX21vZHVsZXMvZGVwcmVjYXRpb24vZGlzdC1ub2RlL2luZGV4LmpzPzhhM2UiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuXG5jbGFzcyBEZXByZWNhdGlvbiBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IobWVzc2FnZSkge1xuICAgIHN1cGVyKG1lc3NhZ2UpOyAvLyBNYWludGFpbnMgcHJvcGVyIHN0YWNrIHRyYWNlIChvbmx5IGF2YWlsYWJsZSBvbiBWOClcblxuICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXG5cbiAgICBpZiAoRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UpIHtcbiAgICAgIEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKHRoaXMsIHRoaXMuY29uc3RydWN0b3IpO1xuICAgIH1cblxuICAgIHRoaXMubmFtZSA9ICdEZXByZWNhdGlvbic7XG4gIH1cblxufVxuXG5leHBvcnRzLkRlcHJlY2F0aW9uID0gRGVwcmVjYXRpb247XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/.pnpm/deprecation@2.3.1/node_modules/deprecation/dist-node/index.js\n");

/***/ })

};
;